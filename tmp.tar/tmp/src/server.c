#include <dlfcn.h>
#include "graph.h"
#include <getopt.h>
#include <time.h>
#include <unistd.h>
#include "player.h"

// Global seed for the random number generator
static int Length = 3;
static char Shape = 'c';
static int show = 0;

////////////////////////////////////////////////////////////////
// Function for parsing the options of the program
// Currently available options are :
// -s <seed> : sets the seed
void parse_opts(int argc, char* argv[]) {
  int opt;
  while ((opt = getopt(argc, argv, "m:t:p:")) != -1) {
    switch (opt) {
    case 'm':
      Length = atoi(optarg);
      break;
    case 't':
      Shape = atoi(optarg);
      break;
    case 'p':
      show = atoi(optarg);
      break;
    default: /* '?' */
      fprintf(stderr, "Usage: %s [-m Length] \n ",
              argv[0]);
      fprintf(stderr, "Usage: %s [-t Shape] \n ",
              argv[0]);
      fprintf(stderr, "Usage: %s [-p show] = 1 to show \n ",
              argv[0]);
    }
  }
}

int is_move_possible(struct graph_t* g, int color, struct move_t move){
  int n = (int) move.m;
  if (move.m != -1 && (gsl_spmatrix_get(g->o, 0, n) == 0) && (gsl_spmatrix_get(g->o, 1, n) == 0)){
    return 1;
  }
  return 0;
}


struct player{
  
  char const *name;
  struct graph_t *graph;
  enum color_t color;
  struct move_t (*propose_opening)();
  int (*accept_opening)(const struct move_t opening);
  void (*initialize_color)(enum color_t id);
  void (*initialize_graph)(struct graph_t* graph);
  struct move_t (*play)(struct move_t previous_move);
  void (*finalize)();
  struct move_t last_move;
  
};


struct player * compute_next_player(struct player *p1, struct player *p2, struct move_t last_move, struct graph_t *graph)
{
  
  if(last_move.c == 0)
    {
     // coloriate__graph_t(graph, p2->color, p2->last_move);
     // p2->last_move = last_move;
      return p2;
    }
    //coloriate__graph_t(graph, p1->color, p1->last_move);
   // p1->last_move = last_move;
    return p1;
  
}



int main(int argc,  char* argv[]){
  
	  printf("*********paramètres du jeu**********");
  parse_opts(argc, argv);
  printf("\nLength : %d\n", Length);
  printf("shape : %d\n", Shape);
//-------------------------------------------
  struct graph_t *graph = new__graph_t(Length, Shape); 
  void * player1 = dlopen("install/player1.so",RTLD_NOW);
  void * player2 = dlopen("install/player2.so",RTLD_NOW);
  
  struct player * p1 = dlsym(player1,"player1");
  
  p1->propose_opening = dlsym(player1,"propose_opening");
  p1->accept_opening = dlsym(player1,"accept_opening");
  p1->initialize_color = dlsym(player1,"initialize_color");
  p1->initialize_graph = dlsym(player1,"initialize_graph");
  p1->play = dlsym(player1,"play");
  p1->finalize = dlsym(player1,"finalize");
  p1->initialize_graph(graph);

  struct player * p2 = dlsym(player2,"player2");

  p2->propose_opening = dlsym(player2,"propose_opening");
  p2->accept_opening = dlsym(player2,"accept_opening");
  p2->initialize_color = dlsym(player2,"initialize_color");
  p2->initialize_graph = dlsym(player2,"initialize_graph");
  p2->play = dlsym(player2,"play");
  p2->finalize = dlsym(player2,"finalize");
  p2->initialize_graph(graph);
	
  struct move_t move = p1->propose_opening();

  p1->initialize_color(1 - p2->accept_opening(move));
  p2->initialize_color(p2->accept_opening(move));

  int end_by_impossible_move = 1;
  struct move_t last_move = {.c = 1 - p1->color, .m = move.m};
  struct player *p = p1;
  int count = width__graph_t(graph) * 4 - 4;
    printf("palyer %s new move %ld , last move %ld\n",p->name, move.m, (p->last_move).m);

  while (1){
    srand(time(NULL));
    print_graph(graph, 'c');
    p = compute_next_player(p1,p2,last_move, graph);
    printf("palyer %s new move %ld , last move %ld\n",p->name, move.m, (p->last_move).m);
    p->last_move = last_move;
    if(is_move_possible(graph, p->color, move)){
      coloriate__graph_t(graph, p->color, p->last_move );
    move = p->play(p->last_move);

    if (is_winning(graph,p->color,(p->last_move),'c'))
    {
          printf("p********** %s new move %ld , last move %ld\n",p->name, move.m, (p->last_move).m);

      break;
    }
    p->last_move = move;
    last_move = move;
  }
  else{
    end_by_impossible_move = -1;
    break;
  }

  }
  print_graph(graph, 'c');
  if (end_by_impossible_move ==-1)
    printf("Equality between players\n");

  free__graph_t(graph);
  dlclose(player1);
  dlclose(player2);

  return 0;
}
